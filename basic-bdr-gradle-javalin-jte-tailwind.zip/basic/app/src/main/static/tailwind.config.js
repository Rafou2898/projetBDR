/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./**/*.jte"],
	theme: {
		extend: {},
	},
	plugins: [],
}

